Visualize dynamically ceph cluster status and relations between ceph cluster objects.
-------------------------------------------------------------------------------------

 It's based on **AngularJS** framework and **D3JS** graphic library
 The installation uses an **Apache** server to solve cross-domain call issues.

 Visualized data are taken directly via Ceph rest API calls and from a MongoDb database.

 Manual installation is described in the [inkScope wiki](https://github.com/inkscope/inkscope/wiki)